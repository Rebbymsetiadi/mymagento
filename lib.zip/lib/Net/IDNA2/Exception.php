<?php
class Net_IDNA2_Exception extends Exception
{
}
